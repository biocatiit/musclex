#!/bin/sh
python -m musclex.tests.module_test
