# The hidden import is necessary for pandas 0.22.0+.
hiddenimports = ['pandas._libs.tslibs.timedeltas','pandas._libs.tslibs.base']

