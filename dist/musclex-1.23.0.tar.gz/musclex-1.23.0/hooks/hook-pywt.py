# The hidden import is necessary for PyWavelets 0.5.2+.
hiddenimports = ['pywt._extensions._cwt']