from distutils.core import setup

setup(
    name='MuscleX',
    version='0.1dev',
    packages=['musclex',],
    license='IIT',
    long_description=open('README.md').read(),
)