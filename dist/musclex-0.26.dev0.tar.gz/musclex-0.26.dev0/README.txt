Muscle X Programs
==============

The Muscle X program suite is a collection of programs intended to assist with analyzing diffraction X-ray images. The collection includes:

- Bio-muscle (bm)
- Quadrant Folding (qf)
- Circular Projection (cp)
- Diffraction Centroids (dc)
- DDF Processor (ddf)